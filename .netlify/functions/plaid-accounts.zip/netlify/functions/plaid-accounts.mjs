
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/plaid-accounts.mjs
import { Configuration, PlaidApi, PlaidEnvironments } from "plaid";
var plaidConfig = new Configuration({
  basePath: PlaidEnvironments[process.env.PLAID_ENV || "sandbox"],
  baseOptions: {
    headers: {
      "PLAID-CLIENT-ID": process.env.PLAID_CLIENT_ID,
      "PLAID-SECRET": process.env.PLAID_SECRET
    }
  }
});
var plaidClient = new PlaidApi(plaidConfig);
async function getAccessToken() {
  const { getStore } = await import("@netlify/blobs");
  const store = getStore("plaid-tokens");
  const data = await store.get("wth");
  if (!data) return null;
  const parsed = JSON.parse(data);
  return parsed.access_token;
}
var plaid_accounts_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET", "Access-Control-Allow-Headers": "Content-Type" } });
  }
  const url = new URL(req.url);
  const action = url.searchParams.get("action");
  const accessToken = await getAccessToken();
  if (!accessToken) {
    return Response.json({ error: "No bank connected. Use Connect Bank first.", connected: false }, { status: 400 });
  }
  try {
    if (action === "balances") {
      const response = await plaidClient.accountsBalanceGet({
        access_token: accessToken
      });
      const accounts = response.data.accounts.map((a) => ({
        id: a.account_id,
        name: a.name,
        officialName: a.official_name,
        type: a.type,
        subtype: a.subtype,
        mask: a.mask,
        balances: {
          available: a.balances.available,
          current: a.balances.current,
          limit: a.balances.limit,
          currency: a.balances.iso_currency_code || "USD"
        }
      }));
      return Response.json({
        accounts,
        institution_id: response.data.item?.institution_id,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    if (action === "transactions") {
      const now = /* @__PURE__ */ new Date();
      const thirtyDaysAgo = /* @__PURE__ */ new Date();
      thirtyDaysAgo.setDate(now.getDate() - 30);
      const startDate = thirtyDaysAgo.toISOString().split("T")[0];
      const endDate = now.toISOString().split("T")[0];
      const response = await plaidClient.transactionsGet({
        access_token: accessToken,
        start_date: startDate,
        end_date: endDate,
        options: { count: 100, offset: 0 }
      });
      const transactions = response.data.transactions.map((t) => ({
        id: t.transaction_id,
        date: t.date,
        name: t.name || t.merchant_name,
        merchant: t.merchant_name,
        amount: t.amount,
        category: t.personal_finance_category?.primary || (t.category ? t.category[0] : "Other"),
        pending: t.pending,
        type: t.amount > 0 ? "expense" : "income"
      }));
      const totalIncome = transactions.filter((t) => t.amount < 0).reduce((sum, t) => sum + Math.abs(t.amount), 0);
      const totalExpenses = transactions.filter((t) => t.amount > 0).reduce((sum, t) => sum + t.amount, 0);
      return Response.json({
        transactions,
        total: response.data.total_transactions,
        summary: {
          income: totalIncome,
          expenses: totalExpenses,
          net: totalIncome - totalExpenses,
          period: `${startDate} to ${endDate}`
        },
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    return Response.json({ error: "Unknown action. Use: balances, transactions" }, { status: 400 });
  } catch (err) {
    console.error("Plaid accounts error:", err.response?.data || err.message);
    return Response.json({
      error: err.response?.data?.error_message || err.message
    }, { status: 500 });
  }
};
var config = { path: "/api/plaid-accounts" };
export {
  config,
  plaid_accounts_default as default
};
