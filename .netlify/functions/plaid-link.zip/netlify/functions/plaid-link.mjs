
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/plaid-link.mjs
import { Configuration, PlaidApi, PlaidEnvironments, Products, CountryCode } from "plaid";
var plaidConfig = new Configuration({
  basePath: PlaidEnvironments[process.env.PLAID_ENV || "sandbox"],
  baseOptions: {
    headers: {
      "PLAID-CLIENT-ID": process.env.PLAID_CLIENT_ID,
      "PLAID-SECRET": process.env.PLAID_SECRET
    }
  }
});
var plaidClient = new PlaidApi(plaidConfig);
var plaid_link_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, GET", "Access-Control-Allow-Headers": "Content-Type" } });
  }
  const url = new URL(req.url);
  const action = url.searchParams.get("action");
  try {
    if (action === "create_link_token") {
      const response = await plaidClient.linkTokenCreate({
        user: { client_user_id: "wth-admin" },
        client_name: "Words That Heal Admin",
        products: [Products.Transactions],
        country_codes: [CountryCode.Us],
        language: "en"
      });
      return Response.json({ link_token: response.data.link_token });
    }
    if (action === "exchange_token") {
      const body = await req.json();
      const response = await plaidClient.itemPublicTokenExchange({
        public_token: body.public_token
      });
      const { getStore } = await import("@netlify/blobs");
      const store = getStore("plaid-tokens");
      await store.set("wth", JSON.stringify({
        access_token: response.data.access_token,
        item_id: response.data.item_id,
        connected_at: (/* @__PURE__ */ new Date()).toISOString()
      }));
      return Response.json({ success: true, item_id: response.data.item_id });
    }
    if (action === "disconnect") {
      const { getStore } = await import("@netlify/blobs");
      const store = getStore("plaid-tokens");
      await store.delete("wth");
      return Response.json({ success: true, disconnected: true });
    }
    if (action === "status") {
      const { getStore } = await import("@netlify/blobs");
      const store = getStore("plaid-tokens");
      const data = await store.get("wth");
      return Response.json({ connected: !!data });
    }
    return Response.json({ error: "Unknown action. Use: create_link_token, exchange_token, disconnect, status" }, { status: 400 });
  } catch (err) {
    console.error("Plaid error:", err.response?.data || err.message);
    return Response.json({
      error: err.response?.data?.error_message || err.message
    }, { status: 500 });
  }
};
var config = { path: "/api/plaid-link" };
export {
  config,
  plaid_link_default as default
};
